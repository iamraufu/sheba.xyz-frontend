import React from 'react';

const AdminCreate = () => {
    return (
        <div>
            
        </div>
    );
};

export default AdminCreate;